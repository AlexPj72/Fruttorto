# Testi Agronomici dei 12 Mesi - Base da validare

## ⚠️ Nota importante per il capoprogetto
Questi testi sono una **base plausibile generata dall'IA** basata su conoscenza generale dell'agricoltura italiana. 
**DEVONO essere validati e corretti** dal capoprogetto (esperto di agronomia) confrontandoli con:
- Disciplinari di produzione integrata regionali
- CREA (crea.gov.it)
- OrtoClima (ortoclima.com)
- La propria esperienza sul campo

---

## 🌿 Struttura del pattern

Ogni mese ha:
- **Titolo evocativo** del mese intero
- **4 settimane** con titolo specifico
- Per ogni settimana: Clima & Suolo, Azione, Divieto, Osservazione, Massima

---

## ❄️ GENNAIO — "il riposo che prepara"
**Clima tipico**: freddo umido, gelate frequenti al Nord, mite variabile al Sud
- **Sett. 1 - Il progetto**: disegna la mappa dell'orto dell'anno
- **Sett. 2 - I semi dell'anno**: ordina i semi, verifica quelli della banca
- **Sett. 3 - Il suolo coperto**: controlla la pacciama, rabbocca dove necessario
- **Sett. 4 - La potatura leggera**: pota solo alberi a foglia caduca a riposo

**Divieto generale**: Non lavorare il suolo bagnato o gelato
**Osservazione**: Sotto la pacciama il suolo resta soffice e profuma di bosco
**Massima**: Chi riposa, prepara.

---

## 🌱 FEBBRAIO — "il risveglio sotto terra"
**Clima tipico**: ancora freddo ma le giornate si allungano
- **Sett. 1 - Il semenzaio**: avvia semenzai protetti (peperoni, pomodori)
- **Sett. 2 - I primi trapianti protetti**: trapianta in tunnel/serra fredda
- **Sett. 3 - Le aromatiche perenni**: prepara il letto delle aromatiche
- **Sett. 4 - La pacciama sottile**: rinnova la pacciama sottile su letti preparati

**Divieto generale**: Non trapiantare all'aperto nelle gelate
**Osservazione**: La terra in superficie si sgrana: è il segnale del risveglio

---

## 🌿 MARZO — "la prima chiamata"
**Clima tipico**: prime giornate calde, rischio gelate tardive
- **Sett. 1 - Semine a pieno campo**: carote, piselli, spinaci
- **Sett. 2 - Trapianti precoci**: aglio, cipolle
- **Sett. 3 - Osserva le erbe spontanee**: indicatori di suolo
- **Sett. 4 - Acqua solo se serve**: non affogare i semenzai

**Divieto generale**: Non vangare: arieggia solo in superficie
**Osservazione**: Le erbe spontanee dicono che il suolo è vivo
**Massima**: Il suolo non si volta, si copre.

---

## 🌼 APRILE — "il grande via"
**Clima tipico**: temperature miti, piogge primaverili
- **Sett. 1 - Semine e trapianti in scala**: gran parte delle estive
- **Sett. 2 - Pacciamatura fresca**: dopo i trapianti
- **Sett. 3 - Acqua al mattino**: evita ristagni notturni
- **Sett. 4 - Osserva gli afidi**: arrivano i primi

**Divieto generale**: Non lasciare il suolo nudo
**Osservazione**: Afidi in piccola quantità: le coccinelle stanno arrivando

---

## 🌻 MAGGIO — "l'abbondanza che esplode"
**Clima tipico**: clima ideale per la crescita
- **Sett. 1 - Trapianti estivi**: zucchine, cetrioli, basilico
- **Sett. 2 - Rabbocco pacciama**: con paglia fresca
- **Sett. 3 - Primi raccolti**: ravanelli, lattughe
- **Sett. 4 - Ombreggi leggeri**: proteggi le giovani

**Divieto generale**: Non concimare a caso: guarda la pianta
**Osservazione**: Foglia troppo scura = troppo azoto

---

## ☀️ GIUGNO — "il sole che chiede acqua"
**Clima tipico**: caldo stabile, temporali possibili
- **Sett. 1 - Acqua profonda e rara**: meglio poco e profondo
- **Sett. 2 - Pacciama spessa**: 15-20 cm per trattenere umidità
- **Sett. 3 - Semine autunnali precoci**: cicorie, finocchi
- **Sett. 4 - Raccolta mattina**: sapore migliore

**Divieto generale**: Non bagnare le foglie
**Osservazione**: Suolo umido sotto 5 cm di pacciama = irrigazione giusta
**Massima**: L'acqua si dà al suolo, non alla foglia.

---

## 🔥 LUGLIO — "il raccolto generoso"
**Clima tipico**: caldo intenso, siccità al Centro-Sud
- **Sett. 1 - Raccolta quotidiana**: zucchine, pomodori, fagioli
- **Sett. 2 - Semine di fine estate**: biete, rape
- **Sett. 3 - Osserva il suolo**: sotto la pacciama
- **Sett. 4 - Prepara il dopo**: cosa dopo le raccolte

**Divieto generale**: Non lasciare frutti maturi in pianta
**Osservazione**: Il suolo deve restare coperto anche a luglio

---

## 🌊 AGOSTO — "il caldo che insegna la pazienza"
**Clima tipico**: calura estrema, temporali violenti
- **Sett. 1 - Ombra e pacciama**: proteggi le giovani
- **Sett. 2 - Acqua la sera**: evapora meno
- **Sett. 3 - Semina autunnale**: broccoli, cavoli
- **Sett. 4 - Riposo al fresco**: evita ore calde

**Divieto generale**: Non lavorare nelle ore calde
**Osservazione**: Se la pacciama è sottile, il suolo si screpola: rabbocca
**Massima**: Il caldo non si combatte, si accompagna.

---

## 🍂 SETTEMBRE — "il secondo inizio"
**Clima tipico**: prime piogge autunnali, temperature miti
- **Sett. 1 - Semine autunnali**: spinaci, lattughe da taglio
- **Sett. 2 - Trapianti di insalate**: radicchio, cicorie
- **Sett. 3 - Raccolta dei semi**: dalle piante migliori
- **Sett. 4 - Ringrazia**: chiude il ciclo estivo

**Divieto generale**: Non scoprire il suolo dopo i raccolti
**Osservazione**: I semi migliori si scelgono dalle piante migliori

---

## 🍁 OTTOBRE — "la coperta sul suolo"
**Clima tipico**: piogge frequenti, temperature in calo
- **Sett. 1 - Pacciama d'inverno**: foglie, paglia, sfalci
- **Sett. 2 - Raccolta degli ultimi frutti**: zucche, cavoli
- **Sett. 3 - Foglie come tesoro**: ammucchiale per compost/pacciama
- **Sett. 4 - Proteggi le radici**: alberi da frutto giovani

**Divieto generale**: Non bruciare i residui: sono cibo
**Osservazione**: Le foglie secche raccolte oggi sono la pacciama di domani

---

## 🦉 NOVEMBRE — "il ringraziamento"
**Clima tipico**: freddo umido, prime gelate al Nord
- **Sett. 1 - Riposo attivo**: osserva e pianifica
- **Sett. 2 - Ripara gli attrezzi**: prepara per la primavera
- **Sett. 3 - Osserva gli uccelli**: lasciali trovare rifugio
- **Sett. 4 - Pianifica piano**: progetto per l'anno prossimo

**Divieto generale**: Non pulire tutto: i residui proteggono
**Osservazione**: Un orto "in ordine" d'inverno è un deserto

---

## 🕯️ DICEMBRE — "il silenzio fertile"
**Clima tipico**: freddo, possibili nevicate al Nord
- **Sett. 1 - Lettura e progetto**: studia, impara
- **Sett. 2 - Semi al fresco**: controlla conservazione
- **Sett. 3 - Il calendario dell'anno**: pianifica semine
- **Sett. 4 - Niente fretta**: rispetta i tempi

**Divieto generale**: Non potare con gelo forte
**Osservazione**: Sotto la neve o la pacciama, la vita continua
**Massima**: Anche il nulla apparente è lavoro.

---

## 📚 Come arricchire questi testi

Per ogni mese, consultare i **disciplinari regionali** di riferimento per aggiungere:
- Varietà specifiche locali (es. pomodoro San Marzano in Campania)
- Date di semina precise per zona
- Trucchi tradizionali regionali
- Parassiti specifici del territorio
